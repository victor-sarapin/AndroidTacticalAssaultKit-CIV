var xmlConceptsData = "";
xmlConceptsData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlConceptsData += '<CatapultTargetConcepts />';
CMCXmlParser._FilePathToXmlStringMap.Add('Concepts', xmlConceptsData);
