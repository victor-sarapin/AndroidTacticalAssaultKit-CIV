var a00061 =
[
    [ "~LTIMetadataReader", "a00061.html#acf6b4579a4a83d0cc70df2b91ed423f8", null ],
    [ "LTIMetadataReader", "a00061.html#a3bf51207dc0471af37e19d43d92e2844", null ],
    [ "read", "a00061.html#af4ba8c4807d5b05dc45a6f46c8cdd451", null ],
    [ "m_database", "a00061.html#abe0080f79c2b85b238dd41f5bd402aac", null ]
];