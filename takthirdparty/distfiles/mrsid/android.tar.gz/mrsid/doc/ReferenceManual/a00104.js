var a00104 =
[
    [ "LTITranslationFilter", "a00104.html#a6d5bffd79548621d0c81ce3a5e2698ba", null ],
    [ "~LTITranslationFilter", "a00104.html#af565bc3c6a86eeb8baefeb210e5c263f", null ],
    [ "create", "a00104.html#a9da5d6ae52941166be12cc54fe1169e2", null ],
    [ "getModifications", "a00104.html#ac25a1a865e34f860b368eaa241c08eae", null ],
    [ "initialize", "a00104.html#ad832ebe910a5ff05bad4f225142d0a57", null ],
    [ "initialize", "a00104.html#a5da02af8615394d123ceffd3235d4040", null ]
];