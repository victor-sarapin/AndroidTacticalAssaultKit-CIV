var a00119 =
[
    [ "SecurityBlock", "a00119.html#a176167df299773494d695e981543a625", null ],
    [ "~SecurityBlock", "a00119.html#a70b9eabc00063330eeefb80faed40ca5", null ],
    [ "addMetadata", "a00119.html#a3ca6bfdafd054ad7e569a52072200c3d", null ],
    [ "getMetadata", "a00119.html#a8a3e9a00559a570111f885b80a626db7", null ]
];