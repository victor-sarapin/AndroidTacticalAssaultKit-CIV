var namespaces =
[
    [ "LizardTech", "a00234.html", "a00234" ],
    [ "LizardTech::Nitf", "a00235.html", null ],
    [ "Nitf", "a00236.html", "a00236" ]
];