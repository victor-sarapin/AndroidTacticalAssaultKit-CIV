var a00072 =
[
    [ "LTIOMemStream", "a00072.html#a87d86e4c26ed6fb5b5d7b48fd23092d9", null ],
    [ "~LTIOMemStream", "a00072.html#ac8170ba97042516ce73047699fe583d9", null ],
    [ "close", "a00072.html#a8911d75983d463d265ffd70424776ac7", null ],
    [ "duplicate", "a00072.html#a00150152deeb185c3438f87abef8bbf0", null ],
    [ "getID", "a00072.html#aa3c026cf3bbc594d428440cc3e053991", null ],
    [ "getLastError", "a00072.html#a5993d0716b948166b777b77bd7246c90", null ],
    [ "initialize", "a00072.html#ac6cd661ead740f50cd9b815d0804e2c7", null ],
    [ "initialize", "a00072.html#a79af75359e6d91ae8014a2cfd6c84854", null ],
    [ "isEOF", "a00072.html#a51766a478894d734742ca269a0253b30", null ],
    [ "isOpen", "a00072.html#a005898c21ea8f0b71297c1cc4828608c", null ],
    [ "open", "a00072.html#a2c3c154584daafa9c5a98fca0f9a6f0a", null ],
    [ "read", "a00072.html#a55adfc102f60ca576191db5ab0e1d08c", null ],
    [ "seek", "a00072.html#a71fb068bc2de8b4073f7fb18fe4b82c7", null ],
    [ "tell", "a00072.html#acdf83996fc7c6a285599705c75103861", null ],
    [ "write", "a00072.html#aee87d0e2d99b9ee83d272811787d4575", null ],
    [ "m_cur", "a00072.html#aedf54eecc970083fe1cf06f05731f441", null ],
    [ "m_data", "a00072.html#a971958f66e69903f4c1700b890ad3c21", null ],
    [ "m_isEOF", "a00072.html#ad40a87402e79e1030ab5ee9738cf7438", null ],
    [ "m_isOpen", "a00072.html#aaa5f5909f2c6023be675ebd2575a3337", null ],
    [ "m_ownsData", "a00072.html#a8d732e5cf8e9e4c5269e0ceb708e21c4", null ],
    [ "m_size", "a00072.html#a93479978c68445c1700208301c29ea51", null ]
];