var a00079 =
[
    [ "getHeight", "a00079.html#a6ec217b0569bab7adf03af6320315076", null ],
    [ "getWidth", "a00079.html#a680142142248fc4aa96959d26ef7d225", null ]
];