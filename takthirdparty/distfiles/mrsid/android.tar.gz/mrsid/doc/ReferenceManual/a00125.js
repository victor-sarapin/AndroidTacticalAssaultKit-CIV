var a00125 =
[
    [ "id", "a00125.html#aa879e3c90e84d968977fea102ad948ad", null ],
    [ "isLocked", "a00125.html#a4ebf5b9c9aec4b1319be2da762adfa72", null ],
    [ "isOptimizable", "a00125.html#a1c44fb4690e8f4a5847acee08d569774", null ],
    [ "numLevels", "a00125.html#a9ced9c37ba433ae4e8ae7adda7658e07", null ],
    [ "subblockSize", "a00125.html#a64e9c8bb52cfd81d493b13df341c7a21", null ],
    [ "type", "a00125.html#a70adad976e662f738a91f40c534b68c9", null ]
];