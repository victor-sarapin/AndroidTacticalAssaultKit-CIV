var a00041 =
[
    [ "LTICropFilter", "a00041.html#a80d614981771f55da580b25925c9003e", null ],
    [ "~LTICropFilter", "a00041.html#a23cbbe62a13692ce9e966fce156c65cb", null ],
    [ "create", "a00041.html#af628e306f7be281a8469d9d36c9ca8fa", null ],
    [ "initialize", "a00041.html#a4103284639aa1d02dbcb6862252b0982", null ]
];