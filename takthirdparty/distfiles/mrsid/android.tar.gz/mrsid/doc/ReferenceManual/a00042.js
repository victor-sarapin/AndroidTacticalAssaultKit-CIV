var a00042 =
[
    [ "LTIDynamicRangeFilter", "a00042.html#a69caf5020b151d1be979d763568c1d43", null ],
    [ "~LTIDynamicRangeFilter", "a00042.html#a8658cdacafdd47b88a57c794a045df26", null ],
    [ "create", "a00042.html#afcfe2f80b80dbe90a7ace5f37f94a018", null ],
    [ "decodeBegin", "a00042.html#a8e29243816964aa8ceb7c5226523fe3d", null ],
    [ "decodeEnd", "a00042.html#a1b606a5ac0d31a8b640e3c1930ab6dd5", null ],
    [ "decodeStrip", "a00042.html#a493cbb1e9c1e4f3161f5e3f66d527650", null ],
    [ "getEncodingCost", "a00042.html#af0a13a680eb7a921b10767613ebca83a", null ],
    [ "getModifications", "a00042.html#aff046bd09cf2c52ee7927c75f254003f", null ],
    [ "getSrcMax", "a00042.html#af0d86b179d124d1b6b6d414e5bf47f2f", null ],
    [ "getSrcMin", "a00042.html#aa4fbeecb48df1fd6b1ea6afb319f097f", null ],
    [ "initialize", "a00042.html#ad5dc4fa8fe16915c515ad4b9406262da", null ],
    [ "initialize", "a00042.html#a8898161ae93947e4fdbb8079fe62b355", null ],
    [ "initialize", "a00042.html#ab83b6622b868a838906fc16d14f75eb5", null ],
    [ "push", "a00042.html#ae12b4cfe4162343276914c6bc47b35ff", null ],
    [ "reinit", "a00042.html#a3b50574da3aa169279a9c0c144b26b5c", null ],
    [ "setDstMinMax", "a00042.html#a14162398976dfc481fbe4b636b09be2c", null ],
    [ "setPixelFillMethod", "a00042.html#a1a6996f30b7c1c871ba2f645c1434a3d", null ],
    [ "setSrcMinMax", "a00042.html#a95068db64f17cbf2adf30c652cfd7300", null ],
    [ "transformBuffer", "a00042.html#ac7f3e3e5b71807bb9f6e57ca8f3107d1", null ],
    [ "transformPixel", "a00042.html#aa69c3f88793808d950d6134f2e9a6f74", null ]
];