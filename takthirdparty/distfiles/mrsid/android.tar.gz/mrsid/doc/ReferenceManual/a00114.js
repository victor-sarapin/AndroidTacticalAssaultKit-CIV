var a00114 =
[
    [ "MrSIDSingleImageReaderBase", "a00114.html#a497060f24b17e740ad160ab5b13bbbe8", null ],
    [ "~MrSIDSingleImageReaderBase", "a00114.html#a6505d86a2a25c1a562f9202e8990687a", null ],
    [ "getEncodingCost", "a00114.html#a123f3686f9cc095e3dc46990d76c5016", null ],
    [ "getModifications", "a00114.html#a8322c64844aa11e5de35a7d8c40de72a", null ],
    [ "init", "a00114.html#a05c2f5102f6ad4cbdbd906a9af11e576", null ],
    [ "m_manager", "a00114.html#a36ff749e48a5527a256c79ae38a9af51", null ]
];