var a00035 =
[
    [ "LabelSegment", "a00035.html#a6640614150770beca21424a68487a044", null ],
    [ "~LabelSegment", "a00035.html#a240aceeca94282487d4cba6244b92f0d", null ],
    [ "addMetadataLocal", "a00035.html#aecc476cf626520a58247dc76bbccb22d", null ],
    [ "getLabelData", "a00035.html#adb31979ab69f6dbc9b9a216ffe79fdcb", null ],
    [ "getLabelDataLength", "a00035.html#a8442a623eca048676ccfa80524072827", null ],
    [ "initialize", "a00035.html#a1393ee1b0c0cf804936e3f3fdf16978a", null ]
];