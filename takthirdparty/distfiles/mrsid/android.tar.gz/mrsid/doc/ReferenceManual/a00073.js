var a00073 =
[
    [ "~LTIOStreamInf", "a00073.html#a1f74ae95cd0e196a3c9334a69ad61a12", null ],
    [ "close", "a00073.html#aeb9e1fe01d2f636f324572838b29b648", null ],
    [ "duplicate", "a00073.html#a23922e75890aec518358de90d3aa2972", null ],
    [ "getID", "a00073.html#a45c26102d58a1f4673e3b77c2adcef83", null ],
    [ "getLastError", "a00073.html#a0031ec8c2b9c11b2b1c83d8d9531e070", null ],
    [ "isEOF", "a00073.html#a518283535597aa9a776d9551db301606", null ],
    [ "isOpen", "a00073.html#a62c22a041738931a01e49c29e63b96ad", null ],
    [ "open", "a00073.html#accdc542561ac115b0817abcbe889f61e", null ],
    [ "read", "a00073.html#a1fc758bc965ae43bff0065165dc0b0f0", null ],
    [ "readString", "a00073.html#adb261c9051934c59049d897c2e623930", null ],
    [ "seek", "a00073.html#a832ce382c724c30242e31841bd7c69a3", null ],
    [ "tell", "a00073.html#abb800475a1d6eca4897d017ff0e2a63c", null ],
    [ "write", "a00073.html#a4e166172633eb0ac5bd404542c1f80dd", null ]
];