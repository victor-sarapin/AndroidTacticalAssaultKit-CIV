var a00085 =
[
    [ "getMaxMagnification", "a00085.html#adca6ea46b3d2c6d36cfb54b928a33d16", null ],
    [ "getMinMagnification", "a00085.html#a02570536138e0fab175de055b008703a", null ]
];