var a00097 =
[
    [ "~LTIProgressDelegate", "a00097.html#a2a031434c4a25e5a24024331537732c6", null ],
    [ "setProgressStatus", "a00097.html#aa5ee93cf0e7ef0f4b64763a6e763f6da", null ]
];