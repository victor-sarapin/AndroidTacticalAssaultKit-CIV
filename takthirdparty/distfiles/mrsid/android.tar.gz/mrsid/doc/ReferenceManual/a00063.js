var a00063 =
[
    [ "lookupName", "a00063.html#a5a5668f20272c545169a72523dbae184", null ],
    [ "lookupProperName", "a00063.html#a5d0e4cd95e24b5161d158e9ff72770fe", null ],
    [ "lookupProperName", "a00063.html#a903256c6f967a00e9402aa5ea3f40cfc", null ],
    [ "lookupTag", "a00063.html#a264ae8729ca658c1203d02a983e879dd", null ],
    [ "name", "a00063.html#aab35f76d34a64536765352704a141c64", null ],
    [ "name", "a00063.html#a9cd9c9ba2adfb214b1ced059b1e4fcca", null ],
    [ "tagClass", "a00063.html#a865360bb88fc3572da0b7469b4e90242", null ]
];