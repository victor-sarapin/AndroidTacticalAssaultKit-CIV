var a00110 =
[
    [ "~MrSIDImageReaderInterface", "a00110.html#aaf7aba570c4fd593b0e536715ee6379c", null ],
    [ "MrSIDImageReaderInterface", "a00110.html#a2826b4f4b0d4e29b6aec79721f0aff21", null ],
    [ "getGeoCoordFromMetadata", "a00110.html#a03871ba5a99f5f968e0eedf617f2780c", null ],
    [ "getMaxWorkerThreads", "a00110.html#a0c751d6433bece4225fd5865e3b7d857", null ],
    [ "getMrSIDGeneration", "a00110.html#a7686872b1825a9b4765b22c36a74675c", null ],
    [ "getMrSIDGeneration", "a00110.html#a8b2c72bced7eba06fb35b15b07facd01", null ],
    [ "getMrSIDGeneration", "a00110.html#a38553af0d926506aff3014dc4a209f71", null ],
    [ "getMrSIDGeneration", "a00110.html#a2d2e3aad1808b3af3d403d72eb75c6df", null ],
    [ "getMrSIDVersion", "a00110.html#a18948f4d7fc05123dc0306f95a11524d", null ],
    [ "getNumLevels", "a00110.html#ab0ce9c742257210225bc05f43b8e23d6", null ],
    [ "init", "a00110.html#a98f400426bfd66a5aeb983a007b240db", null ],
    [ "isLocked", "a00110.html#a24c1b2d3dddc57619a512b0b3a333ea3", null ],
    [ "openWorldFileStream", "a00110.html#a2bef8f6c352a2fe403ac6ff62e7fe608", null ],
    [ "setMaxWorkerThreads", "a00110.html#a38429125e7b6c6c582ec6b9533cc888a", null ],
    [ "setPassword", "a00110.html#acd395425b769b92be3ebd17943d41713", null ],
    [ "setPasswordDelegate", "a00110.html#a3c8251d027f6df1a25017a00a093c969", null ],
    [ "m_magic", "a00110.html#afb7d7eb865d82bea27968d099457ad28", null ],
    [ "m_memoryUsage", "a00110.html#ab5baba96f9e56ce2f13bf68837b0e288", null ],
    [ "m_streamUsage", "a00110.html#a24d7a666f3810a2166ca357169219f25", null ]
];