var a00118 =
[
    [ "ReservedSegment", "a00118.html#abdf3f8d4825b716f0a7ec8153ce36627", null ],
    [ "~ReservedSegment", "a00118.html#a743586bc2501fcc81dfadbe936782637", null ],
    [ "addMetadataLocal", "a00118.html#a4f9004d4d23511f3fe7d195a1550d5bd", null ],
    [ "initialize", "a00118.html#a3d34015b76cf4fc99c54029828f00407", null ]
];