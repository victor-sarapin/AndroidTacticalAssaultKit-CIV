var a00047 =
[
    [ "LTIGeoImageReader", "a00047.html#a73f092e56ed9586000d8ab34084e2865", null ],
    [ "getUseWorldFile", "a00047.html#a220031c4bd5c675d8c56285901dd9399", null ],
    [ "init", "a00047.html#a1cca12ac27378b24bbc67d12b445be43", null ],
    [ "readWorldFile", "a00047.html#a8d503eb2c20f6f3ef5b117dffcfab6d1", null ],
    [ "readWorldFile", "a00047.html#a559dc54d49a14548cedba5e00f4f8af4", null ]
];