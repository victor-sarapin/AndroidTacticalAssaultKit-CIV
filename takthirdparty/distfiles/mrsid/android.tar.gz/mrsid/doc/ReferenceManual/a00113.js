var a00113 =
[
    [ "MrSIDSimplePasswordDelegate", "a00113.html#af81e5b0d077f7f16701e57c8416f6d68", null ],
    [ "getPassword", "a00113.html#aff65be880884e6b540cb526bac7822ab", null ],
    [ "reportIncorrectPassword", "a00113.html#ac11a69b906fd08ba1f5e563435ee8d41", null ]
];