var a00093 =
[
    [ "getStripHeight", "a00093.html#ad698a28564b020b609f3c0a82e0acb3a", null ],
    [ "setStripHeight", "a00093.html#a42716b0375aa4ee964734ae7d950ed70", null ]
];