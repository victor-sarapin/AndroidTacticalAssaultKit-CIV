#!/bin/sh

set -e

echo "finished"
